class SimpleDB {
  constructor() {
    this.books = [];
    this.users = [];
    this.sessions = [];
  }
}

module.exports = new SimpleDB();