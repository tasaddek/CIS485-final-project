const express = require('express');
const cookieParser = require('cookie-parser');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(express.static('public'));

const db = {
  users: [],
  books: []
};

const authenticate = (req, res, next) => {
  const token = req.cookies?.token;
  if (!token) return res.status(401).send('Unauthorized');
  
  try {
    req.user = jwt.verify(token, 'bookstore-secret');
    next();
  } catch {
    res.status(401).send('Invalid token');
  }
};

app.post('/api/signup', (req, res) => {
  const { username, password } = req.body;
  if (db.users.some(u => u.username === username)) {
    return res.status(400).json({ error: 'Username exists' });
  }
  
  const user = {
    id: uuidv4(),
    username,
    password: bcrypt.hashSync(password, 10)
  };
  
  db.users.push(user);
  res.json({ message: 'User created' });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.users.find(u => u.username === username);
  
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  const token = jwt.sign({ id: user.id }, 'bookstore-secret');
  res.cookie('token', token, { httpOnly: true });
  res.json({ message: 'Logged in' });
});

app.get('/api/books', authenticate, (req, res) => {
  res.json(db.books);
});

// Start server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  // Add test user
  db.users.push({
    id: uuidv4(),
    username: 'test',
    password: bcrypt.hashSync('test', 10)
  });
});