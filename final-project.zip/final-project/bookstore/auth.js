const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./simpleDB');

const JWT_SECRET = 'bookstore-secret-123';

class AuthService {
  static createUser({ username, password }) {
    if (db.users.some(u => u.username === username)) {
      throw new Error('Username already exists');
    }
    
    const user = {
      id: uuidv4(),
      username,
      password: bcrypt.hashSync(password, 10),
      role: 'user'
    };
    
    db.users.push(user);
    return user;
  }

  static authenticate({ username, password }) {
    const user = db.users.find(u => u.username === username);
    if (!user || !bcrypt.compareSync(password, user.password)) {
      throw new Error('Invalid credentials');
    }
    
    return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET);
  }

  static middleware(req, res, next) {
    try {
      const token = req.cookies['bookstore-auth'];
      req.user = jwt.verify(token, JWT_SECRET);
      next();
    } catch (error) {
      res.status(401).send('Unauthorized');
    }
  }
}

module.exports = { AuthService };