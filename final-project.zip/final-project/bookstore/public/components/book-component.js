class BookComponent extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  static get observedAttributes() {
    return ['title', 'author'];
  }

  attributeChangedCallback() {
    this.render();
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>
        .book {
          border: 1px solid #ccc;
          padding: 1rem;
          margin: 1rem;
          border-radius: 8px;
        }
      </style>
      <div class="book">
        <h3>${this.getAttribute('title')}</h3>
        <p>By ${this.getAttribute('author') || 'Unknown'}</p>
      </div>
    `;
  }
}

customElements.define('book-component', BookComponent);