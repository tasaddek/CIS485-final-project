
{
  users: [
    {
      id: "abc123",
      credits: 5,
      sharedBooks: 3,
      joinedAt: "2023-10-01"
    }
  ],
  books: [
    {
      id: "book1",
      owner: "abc123",
      status: "available",
      title: "Silent Spring"
    }
  ],
  carbonStats: {
    totalShared: 42,
    lastUpdated: "2023-10-05"
  }
}